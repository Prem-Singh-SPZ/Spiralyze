var content = document.createElement("script");
content.src =
  "https://res.cloudinary.com/spiralyze/raw/upload/f_auto/AWR/3007/products.js";
document.head.appendChild(content);
let coverRepairSection;
content.onload = function () {
  function updatePageContent() {
    if (document.querySelector('button[angularticscategory="Header-Login"]')) {
      if (
        document.querySelector(
          ".general-section .program-content .covered-repair-section"
        ) == null
      ) {
        cloneElement(
          "#covered-repair-section",
          ".general-section .content-box .description-heading-text-content"
        );

        let ocTxt = document.querySelector(
          ".general-section[_ngcontent-c9] .content-box[_ngcontent-c9] .middle-section[_ngcontent-c9] .col-12 li"
        );
        if (ocTxt && ocTxt.textContent.trim().length > 0) {
          ocTxt = ocTxt.textContent.trim();
          document
            .querySelector(
              ".general-section .program-content .description-heading-text-content > p"
            )
            .insertAdjacentHTML(
              "afterend",
              `<div _ngcontent-c9="" class="no-mobile middle-section ng-tns-c9-0 ng-star-inserted">
                        <div _ngcontent-c9="" class="col-12 PD-0">
                            <ul _ngcontent-c9="" class="ng-tns-c9-0">
                                <!----><li _ngcontent-c9="" class="ng-tns-c9-0 ng-star-inserted"> ${ocTxt}</li>
                            </ul>
                        </div>
                    </div>`
            );
        }

        const wcCount =
          ".description-heading-text-content #covered-repair-section .covered-repairs-list.initial li";
        if (
          window.innerWidth >= 1022 &&
          document.querySelectorAll(wcCount).length > 10
        ) {
          document
            .querySelector(wcCount + ":nth-child(1n + 9)")
            .insertAdjacentHTML(
              "afterend",
              `
                    <li _ngcontent-c11="" class="ng-star-inserted see-more">
                        <a href="javascript:void(0)">See more
                            <img class="sm-arrow" src="//res.cloudinary.com/spiralyze/image/upload/v1658250753/AWR/3007/chevron-down.svg" />
                        </a>
                    </li>`
            );

          const wcLi = document.querySelectorAll(
            ".covered-repair-section .covered-repairs-list.initial li"
          );
          for (const li of wcLi) {
            li.classList.remove("show");
          }

          document
            .querySelector(
              ".covered-repair-section .covered-repairs-list.initial li.see-more"
            )
            .addEventListener("click", function () {
              document
                .querySelector(".covered-repair-section .see-more")
                .remove();
              document
                .querySelector(
                  ".covered-repair-section .covered-repairs > .col-12"
                )
                .classList.add("scroll-li");
              for (const li of wcLi) {
                li.classList.add("show");
              }
            });
        } else if (
          document.querySelector(".covered-repair-section .see-more")
        ) {
          document.querySelector(".covered-repair-section .see-more").remove();
        }

        // if (document.querySelectorAll('.selected-zipcode-area .zipcode-searched').length > 0 && document.querySelectorAll('#price-and-zip').length == 0) {
        //     document.querySelector('.selected-zipcode-area').insertAdjacentHTML('afterbegin', '<div id="price-and-zip">Test 0</div>');
        //     cloneElement('#general-section .selected-zipcode-area .zipcode-searched.except-mobile-only', '#price-and-zip');
        //     document.querySelector('#price-and-zip .except-mobile-only').classList.remove('except-mobile-only')
        // }
      }

      if (
        document.querySelector(
          ".general-section .detail-header-section .program-name h3"
        ) &&
        document.querySelector(
          ".breadcrumb-wrapper .custom-breadcrumb ul li.active"
        )
      ) {
        pages.filter((item) => {
          if (
            item.productFilterName ===
            window.location.pathname.split("/")[
              window.location.pathname.split("/").length - 1
            ]
          ) {
            document.querySelector(
              ".general-section .detail-header-section .program-name h3"
            ).innerText = item.productNewName;
            const prImageElem = document.querySelector(
              ".general-section .bg-banner-img .banner-img"
            );
            if (
              document.querySelectorAll(
                ".general-section .bg-banner-img .banner-image-div .banner-img"
              ).length == 0
            ) {
              document
                .querySelector(
                  ".general-section .bg-banner-img .banner-image-div"
                )
                .insertAdjacentHTML(
                  "afterbegin",
                  '<img _ngcontent-c9="" class="banner-img ng-tns-c9-0 ng-star-inserted" loading="lazy" src="' +
                    item.productImage +
                    '">'
                );
              document
                .querySelector(
                  ".general-section .bg-banner-img .except-mobile-only"
                )
                .classList.remove("except-mobile-only");
            }
            if (prImageElem && window.innerWidth < 768) {
              prImageElem.src =
                "https://res.cloudinary.com/spiralyze/image/upload/v1664890464/AWR/3017/assets/Hero-Image_Mobile.jpg";
            } else if (prImageElem && window.innerWidth < 1024) {
              prImageElem.src =
                "https://res.cloudinary.com/spiralyze/image/upload/v1664890464/AWR/3017/assets/Hero-Image_Tablet.jpg";
            } else {
              if (prImageElem) {
                prImageElem.src =
                  "https://res.cloudinary.com/spiralyze/image/upload/v1664890464/AWR/3017/assets/Hero-Image_Desktop.jpg";
              }
            }
            if (window.innerWidth < 768) {
              if (prImageElem) {
                document.querySelector(
                  ".mobile-banner-img .mob-banner-img"
                ).src =
                  "https://res.cloudinary.com/spiralyze/image/upload/v1664890464/AWR/3017/assets/Hero-Image_Mobile.jpg";
              }
            }
            if (document.querySelector(".spz-cover-description")) {
              document.querySelector(".spz-cover-description").innerText =
                item.coverSubheading;
              // document.querySelector('.breadcrumb-wrapper .custom-breadcrumb ul li.active').innerText = item.productNewName
            }
          }
        });
      }
    } else {
      document.querySelector("body").classList.remove("spz-3007-tc");
    }
  }
  function rerenderRelated() {
    if (document.querySelector('button[angularticscategory="Header-Login"]')) {
      document
        .querySelectorAll("#tab-neighbourhood-service-id .card")
        .forEach((cardItem, index) => {
          relatedProducts.filter((item) => {
            if (
              cardItem.children[0] &&
              cardItem.children[0].innerText === item.productFilterName &&
              document.querySelectorAll(".related-item-desc").length < 4
            ) {
              var desc = document.createElement("div");
              desc.classList.add("related-item-desc");
              desc.innerHTML =
                '<div class="description">' +
                item.coverSubheading +
                '</div><div class="spz-learn-more">Learn More</div>';
              cardItem.children[0].innerText = item.productNewName;
              cardItem.children[1].src = item.productMobileImage;
              cardItem.appendChild(desc);
              jQuery(cardItem)
                .find(".small-txt")
                .text(
                  jQuery(cardItem).find(".small-txt").text().replace("Per", "")
                );
              jQuery(".spz-learn-more").click(function () {
                jQuery(this).parent().parent().find(".program-name").click();
              });
            }
          });
        });
    } else {
      document.querySelector("body").classList.remove("spz-3007-tc");
    }
  }
  setInterval(function () {
    document
      .querySelectorAll('.collapse[data-parent="#faq-accordion"]')
      .forEach((item) => {
        if (item.classList.contains("show")) {
          item.parentElement.classList.add("toggle-bg");
        } else {
          item.parentElement.classList.remove("toggle-bg");
        }
      });
  });
  const intr = setInterval(function () {
    if (document.querySelector('button[angularticscategory="Header-Login"]')) {
      if (
        /https:\/\/www.awrusa.com\/([a-zA-Z]*\/)?product\/\d\d\d\d\d\/[a-zA-Z][a-zA-Z]\d\d\d\/residential\/(.*)?/.test(
          window.location.href
        )
      ) {
        if (!document.body.classList.contains("spz-3017")) {
          document.body.classList.add("spz-3007-tc");
          document.body.classList.add("spz-3017");
        }
        if (
          !document.querySelector(".tab-review-container") &&
          document.getElementById("tab-review-section")
        ) {
          document.querySelector(
            "#tab-review-section article:last-child"
          ).innerHTML =
            '\
                <div class="tab-review-container">\
                    <div class="tab-review-slider">\
                        <div class="tab-review-item">\
                            <img src="https://res.cloudinary.com/spiralyze/image/upload/f_auto/AWR/3007-tc/barbara-r.png" alt="Barbara R"/>\
                            <div class="review-copy">So glad we signed up for this program best thing we ever did as homeowners!</div>\
                            <div class="person-name">Barbara R.</div>\
                            <div class="person-location">New York - Water Line Leak</div>\
                        </div>\
                        <div class="tab-review-item">\
                            <img src="https://res.cloudinary.com/spiralyze/image/upload/f_auto/AWR/3007-tc/carol-m.png" alt="Carol M"/>\
                            <div class="review-copy">My neighbors spent thousands for the same work.</div>\
                            <div class="person-name">Carol M.</div>\
                            <div class="person-location">Oklahoma - Sewer Line Blockage</div>\
                        </div>\
                        <div class="tab-review-item">\
                            <img src="https://res.cloudinary.com/spiralyze/image/upload/f_auto/AWR/3007-tc/theodora-d.png" alt="Theodora D"/>\
                            <div class="review-copy">You saved us thousands!</div>\
                            <div class="person-name">Theodora D.</div>\
                            <div class="person-location">Iowa - Leaking Valve</div>\
                        </div>\
                    </div>\
                </div>\
                ';
          var slickStyle = document.createElement("link");
          slickStyle.href =
            "https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css";
          slickStyle.rel = "stylesheet";
          document.head.appendChild(slickStyle);
          var slickScript = document.createElement("script");
          slickScript.src =
            "https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js";
          document.head.appendChild(slickScript);
          slickScript.onload = function () {
            jQuery(".tab-review-slider").slick({
              autoplay: true,
              prevArrow:
                '<img src="https://res.cloudinary.com/spiralyze/image/upload/v1652574953/AWR/3007-tc/prev-arrow.svg" class="prev-arrow"/>',
              nextArrow:
                '<img src="https://res.cloudinary.com/spiralyze/image/upload/v1652574954/AWR/3007-tc/next-arrow.svg" class="next-arrow"/>',
            });
          };
        }
        const tabLinks = document.querySelectorAll("button.tablinks");
        if (
          (tabLinks &&
            tabLinks[0] &&
            tabLinks[0].innerText == "What's Covered") ||
          (tabLinks &&
            tabLinks[0] &&
            tabLinks[0].innerText == "Covered Repairs")
        ) {
          tabLinks[0].parentNode.remove();
          // tabLinks[0].innerText = 'What\'s Covered';
        }
        const secTitle = document.querySelector(
          ".covered-repair-section .section-head-title.font-unbounce-title"
        );
        if (secTitle && secTitle.innerText !== "What's Covered") {
          secTitle.innerText = "What's Covered";
        }
        const faqTitle = document.querySelector(
          "#tab-faq-section .section-head-title"
        );
        if (faqTitle && faqTitle.innerText !== "Frequently Asked Questions") {
          faqTitle.innerText = "Frequently Asked Questions";
        }
        if (
          document.querySelector(".enroll-now-btn") &&
          document.querySelector(".enroll-now-btn").innerText !== "Add to Cart"
        ) {
          document.querySelector(".enroll-now-btn").innerText = "Add to Cart";
          document
            .querySelector(".enroll-now-btn")
            .setAttribute("title", "Add to Cart");
        }
        if (
          document.querySelectorAll(".product-detail-body .tab .tab-div")
            .length === 5
        ) {
          document
            .querySelectorAll(".product-detail-body .tab .tab-div")[0]
            .remove();
          document.querySelector("#tab-benefit-section").remove();
          document
            .querySelectorAll(".product-detail-body .tab .tab-div")[0]
            .classList.add("active");
          document
            .querySelector("#tabs")
            .insertBefore(
              document.querySelectorAll(
                ".product-detail-body .tab .tab-div"
              )[1],
              document.querySelectorAll(".product-detail-body .tab .tab-div")[3]
            );
          document
            .querySelector("#scroll-spy-id")
            .insertBefore(
              document.querySelector("#tab-faq-section"),
              document.querySelector("#tab-neighbourhood-service-id")
            );
        }
        // const pdZipTxt = document.querySelector('#general-section .no-zipcode-search .search-zipcode-area hos-google-places .product-details-zip-text');
        // if (pdZipTxt && document.querySelectorAll('.your-zipcode-label').length == 0) {
        //     document.querySelector('#general-section .no-zipcode-search .search-zipcode-area hos-google-places .product-details-zip-text').insertAdjacentHTML('afterend', `<div class="your-zipcode-label">YOUR ZIP CODE:</div>`);
        // }
        // if (pdZipTxt && document.querySelector('form.search .product-page-search').innerText != 'Get Started') {
        //     document.querySelector('form.search .product-page-search').innerText = 'Get Started';
        // }
        document
          .querySelectorAll(".card .card-body .enroll-now")
          .forEach((item) => {
            if (item.innerText !== "Add to Cart") {
              item.innerText = "Add to Cart";
              item.setAttribute("title", "Add to Cart");
            }
          });
        if (
          !document.querySelector("#general-section") &&
          document.querySelector("#scroll-spy-id")
        ) {
          if (window.innerWidth < 1024 && window.innerWidth > 767) {
            document.querySelector("#scroll-spy-id").style.paddingTop =
              "1200px";
          }
          if (window.innerWidth > 1023) {
            document.querySelector("#scroll-spy-id").style.paddingTop = "850px";
          }
          if (window.innerWidth < 768) {
            document.querySelector("#scroll-spy-id").style.paddingTop = "350px";
          }
        } else if (document.querySelector("#scroll-spy-id")) {
          document.querySelector("#scroll-spy-id").style.paddingTop = "0";
        }
        if (document.querySelector(".rating-btn")) {
          document
            .querySelector(".rating-btn")
            .parentElement.parentElement.classList.add("reviews-wrapper-spz");
        }
        if (
          document.querySelector(".detail-header-section .enroll-btn") &&
          document.querySelector(".detail-header-section .enroll-btn")
            .innerText !== "Add to Cart"
        ) {
          document.querySelector(
            ".detail-header-section .enroll-btn"
          ).innerText = "Add to Cart";
          document
            .querySelector(".detail-header-section .enroll-btn")
            .setAttribute("title", "Add to Cart");
        }
        if (
          document.querySelector(
            ".selected-zipcode-area.mobile-screen-only.fixed-header .program-content .zipcode-searched-mobile .pricing-box .enroll-now-btn-mob"
          ) &&
          document.querySelector(
            ".selected-zipcode-area.mobile-screen-only.fixed-header .program-content .zipcode-searched-mobile .pricing-box .enroll-now-btn-mob"
          ).innerText !== "Add to Cart"
        ) {
          document.querySelector(
            ".selected-zipcode-area.mobile-screen-only.fixed-header .program-content .zipcode-searched-mobile .pricing-box .enroll-now-btn-mob"
          ).innerText = "Add to Cart";
          document
            .querySelector(
              ".selected-zipcode-area.mobile-screen-only.fixed-header .program-content .zipcode-searched-mobile .pricing-box .enroll-now-btn-mob"
            )
            .setAttribute("title", "Add to Cart");
        }
        updatePageContent();
        rerenderRelated();
      }
    } else {
      document.querySelector("body").classList.remove("spz-3007-tc");
    }
  }, 100);
  // setTimeout(function() {
  //     clearInterval(intr);
  // }, 2000)
};

function moveElement(source, target) {
  const f = document.createDocumentFragment();
  if (document.querySelector(source) != null) {
    f.appendChild(document.querySelector(source));
    document.querySelector(target).appendChild(f);
  }
}

function cloneElement(source, target) {
  if (document.querySelector(source) && document.querySelector(target)) {
    const sc = document.querySelector(source);
    const clone = sc.cloneNode(true);
    document.querySelector(target).appendChild(clone);
  }
}

/*JS insertBefore for DOM manipulation*/
function insertBefore(el, referenceNode) {
  referenceNode.parentNode.insertBefore(el, referenceNode);
}
/*JS insertAfter for DOM manipulation*/
function insertAfter(el, referenceNode) {
  referenceNode.parentNode.insertBefore(el, referenceNode.nextSibling);
}

const faq_3017 = setInterval(function () {
  if (
    document.querySelectorAll(
      "#tab-faq-section hos-product-faq .card-header a .faq-text"
    ).length > 0
  ) {
    clearInterval(faq_3017);
    console.log("this is running..");
    const listQues = document.querySelectorAll("hos-product-faq .card-header a .faq-text");
    const listAns = document.querySelectorAll("hos-product-faq .card-block p");
    for (let i = 0; i < listQues.length; i++) {
        listQues[i].innerText = listQues[i].innerText.slice(2);
        listAns[i].innerText = listAns[i].innerText.slice(2);
    }

    let ansDiv = "<div class=ans-div>A.</div>";
    jQuery(ansDiv).insertBefore("hos-product-faq .card-block p");
    
  }
},100);
